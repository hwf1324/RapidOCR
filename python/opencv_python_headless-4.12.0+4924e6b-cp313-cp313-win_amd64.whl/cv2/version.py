opencv_version = "4.12.0+4924e6b"
contrib = False
headless = True
rolling = False
ci_build = False